# Downstream Step 2 Fixture

This fixture provides fixed per-sample FASTQ inputs for the downstream
workflow. Its expected output includes the seven-locus profiles and
sequence types for all 10 samples. The fixture contains 11,949 reads.
Its read counts describe these fixed inputs. Table 1 reports read counts
from the full study analysis.

Contents:

- `input/merged_by_sample/`: exact Step 1 outputs used as downstream inputs
- `expected/`: reference outputs for Step 2-4 validation
- `validate_outputs.py`: compares a tester's Step 2-4 outputs against the
  expected reference results

Create the two conda environments in the repository README and place a
PubMLST profile table at `db/saureus_Profile.txt` as described in
`db/README.md`. After extracting the archive using Option C, run these
commands from the repository root.

```bash
FIXTURE_DIR=output/fixture_inputs/downstream_step2_fixture

bash code/04_assembly_polish_pipeline.sh \
  --sample-fastq-dir="${FIXTURE_DIR}/input/merged_by_sample" \
  --assembly-output-dir=output/fixture_run/02_assembly \
  --mlst-output-dir=output/fixture_run/03_mlst \
  --assembly-env=nanopore-assembly-mlst-macos-arm64 \
  --mlst-env=mlst-only \
  --threads=4 \
  --mlst-threads=1 \
  --genome-size=4k \
  --asm-coverage=40 \
  --min-overlap=1000 \
  --medaka-model=r941_min_sup_g507 \
  --scheme=saureus

python3 code/05_infer_st_from_partial_mlst.py \
  --mlst-summary=output/fixture_run/03_mlst/mlst_sample_summary.tsv \
  --profile-table=db/saureus_Profile.txt \
  --output-dir=output/fixture_run/04_st_guess \
  --top-n=10

python3 code/06_build_publication_style_mlst_table.py \
  --assembly-summary=output/fixture_run/02_assembly/assembly_polish_summary.tsv \
  --mlst-summary=output/fixture_run/03_mlst/mlst_sample_summary.tsv \
  --st-guess-summary=output/fixture_run/04_st_guess/st_guess_summary.tsv \
  --output-path=output/fixture_run/Result_Table/fixture_publication.tsv

python3 "${FIXTURE_DIR}/validate_outputs.py" \
  --assembly-summary=output/fixture_run/02_assembly/assembly_polish_summary.tsv \
  --mlst-summary=output/fixture_run/03_mlst/mlst_sample_summary.tsv \
  --st-guess-summary=output/fixture_run/04_st_guess/st_guess_summary.tsv \
  --publication-table=output/fixture_run/Result_Table/fixture_publication.tsv
```

The validator checks the following files against this fixture's references:

- `final_publication.tsv` must match exactly
- `st_guess_summary.tsv` must match exactly
- assembly summary is compared on stable semantic columns
- MLST summary is compared on stable semantic columns, not output-path columns

Notes:

- Assembly FASTA file bytes may differ across environments even when the final
  typing result is unchanged.
- The validator is the intended pass/fail gate for this fixture.
