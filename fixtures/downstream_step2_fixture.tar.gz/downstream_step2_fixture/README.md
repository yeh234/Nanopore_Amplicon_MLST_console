# Downstream Step 2 Fixture

This fixture is for testers who should start from Step 2 instead of uploading
the original raw `Samlst_SUP.fastq.gz`.

Contents:

- `input/merged_by_sample/`: exact Step 1 outputs used as downstream inputs
- `expected/`: reference outputs for Step 2-4 validation
- `validate_outputs.py`: compares a tester's Step 2-4 outputs against the
  expected reference results

Recommended run:

```bash
bash code/04_step4_to_step6_pipeline.sh \
  --sample-fastq-dir=fixtures/downstream_step2_fixture/input/merged_by_sample \
  --assembly-output-dir=output/fixture_run/02_assembly \
  --mlst-output-dir=output/fixture_run/03_mlst \
  --assembly-env=nanopore-assembly-mlst-macos-arm64 \
  --mlst-env=mlst-only \
  --threads=4 \
  --mlst-threads=1 \
  --genome-size=4k \
  --asm-coverage=40 \
  --min-overlap=1000 \
  --medaka-model=r941_min_sup_g507 \
  --scheme=saureus

python3 code/05_infer_st_from_partial_mlst.py \
  --mlst-summary=output/fixture_run/03_mlst/mlst_sample_summary.tsv \
  --profile-table=db/saureus_ProfileSelect.txt \
  --output-dir=output/fixture_run/04_st_guess \
  --top-n=10

python3 code/06_build_publication_style_mlst_table.py \
  --assembly-summary=output/fixture_run/02_assembly/assembly_polish_summary.tsv \
  --mlst-summary=output/fixture_run/03_mlst/mlst_sample_summary.tsv \
  --st-guess-summary=output/fixture_run/04_st_guess/st_guess_summary.tsv \
  --output-path=output/fixture_run/Result_Table/fixture_publication.tsv

python3 fixtures/downstream_step2_fixture/validate_outputs.py \
  --assembly-summary=output/fixture_run/02_assembly/assembly_polish_summary.tsv \
  --mlst-summary=output/fixture_run/03_mlst/mlst_sample_summary.tsv \
  --st-guess-summary=output/fixture_run/04_st_guess/st_guess_summary.tsv \
  --publication-table=output/fixture_run/Result_Table/fixture_publication.tsv
```

Validation guarantees:

- `final_publication.tsv` must match exactly
- `st_guess_summary.tsv` must match exactly
- assembly summary is compared on stable semantic columns
- MLST summary is compared on stable semantic columns, not output-path columns

Notes:

- Assembly FASTA file bytes may differ across environments even when the final
  typing result is unchanged.
- The validator is the intended pass/fail gate for this fixture.
