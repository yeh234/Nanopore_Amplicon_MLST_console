#!/usr/bin/env python3

import argparse
import csv
import sys
from pathlib import Path


ASSEMBLY_COLUMNS = ["sample", "read_count", "status"]
MLST_COLUMNS = [
    "sample",
    "scheme",
    "ST",
    "STATUS",
    "SCORE",
    "arcC_allele",
    "aroE_allele",
    "glpF_allele",
    "gmk_allele",
    "pta_allele",
    "tpi_allele",
    "yqiL_allele",
    "typing_status",
]
ST_GUESS_KEY = "sample"
PUBLICATION_KEY = "SampleNo."


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        return list(reader)


def project_rows(rows: list[dict[str, str]], columns: list[str]) -> list[dict[str, str]]:
    return [{column: row.get(column, "") for column in columns} for row in rows]


def rows_by_key(rows: list[dict[str, str]], key: str) -> dict[str, dict[str, str]]:
    return {row[key]: row for row in rows}


def compare_exact(actual_path: Path, expected_path: Path, label: str) -> list[str]:
    actual = actual_path.read_text(encoding="utf-8")
    expected = expected_path.read_text(encoding="utf-8")
    if actual == expected:
        return []
    return [f"{label}: file contents differ"]


def compare_projected(
    actual_path: Path,
    expected_path: Path,
    key: str,
    columns: list[str],
    label: str,
) -> list[str]:
    actual_rows = rows_by_key(project_rows(read_tsv(actual_path), columns), key)
    expected_rows = rows_by_key(project_rows(read_tsv(expected_path), columns), key)

    errors: list[str] = []
    actual_keys = set(actual_rows)
    expected_keys = set(expected_rows)
    if actual_keys != expected_keys:
        missing = sorted(expected_keys - actual_keys)
        extra = sorted(actual_keys - expected_keys)
        if missing:
            errors.append(f"{label}: missing keys: {', '.join(missing)}")
        if extra:
            errors.append(f"{label}: unexpected keys: {', '.join(extra)}")
        return errors

    for row_key in sorted(expected_keys):
        if actual_rows[row_key] != expected_rows[row_key]:
            errors.append(
                f"{label}: mismatch at {key}={row_key}\n"
                f"  expected: {expected_rows[row_key]}\n"
                f"  actual:   {actual_rows[row_key]}"
            )
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Validate Step 2-4 outputs against the downstream fixture reference."
    )
    parser.add_argument("--assembly-summary", required=True)
    parser.add_argument("--mlst-summary", required=True)
    parser.add_argument("--st-guess-summary", required=True)
    parser.add_argument("--publication-table", required=True)
    parser.add_argument(
        "--expected-dir",
        default=str(Path(__file__).resolve().parent / "expected"),
        help="Directory containing expected fixture outputs.",
    )
    args = parser.parse_args()

    expected_dir = Path(args.expected_dir)
    errors: list[str] = []

    errors.extend(
        compare_projected(
            Path(args.assembly_summary),
            expected_dir / "assembly_summary_semantic.tsv",
            key="sample",
            columns=ASSEMBLY_COLUMNS,
            label="assembly summary",
        )
    )
    errors.extend(
        compare_projected(
            Path(args.mlst_summary),
            expected_dir / "mlst_summary_semantic.tsv",
            key="sample",
            columns=MLST_COLUMNS,
            label="mlst summary",
        )
    )
    errors.extend(
        compare_exact(
            Path(args.st_guess_summary),
            expected_dir / "st_guess_summary.tsv",
            label="st_guess summary",
        )
    )
    errors.extend(
        compare_exact(
            Path(args.publication_table),
            expected_dir / "final_publication.tsv",
            label="final publication table",
        )
    )

    if errors:
        print("Validation failed:", file=sys.stderr)
        for error in errors:
            print(error, file=sys.stderr)
        return 1

    print("Validation passed.")
    print("Matched assembly semantic summary, MLST semantic summary, ST guess summary, and final publication table.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
